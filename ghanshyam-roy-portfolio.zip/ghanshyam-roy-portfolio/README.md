# Ghanshyam Roy — Portfolio Website

Premium personal portfolio website with a Samsung-inspired dark blue futuristic design.

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Tech Stack

- React 19 + TypeScript
- Vite 6
- Tailwind CSS v4
- Framer Motion (animations)
- React Icons

## Project Structure

```
src/
  components/
    sections/       # All page sections (Hero, About, Skills, etc.)
    CursorGlow.tsx  # Custom cursor effect
  lib/
    utils.ts        # Tailwind utility helper
  hooks/            # Custom React hooks
  App.tsx           # Root component
  main.tsx          # Entry point
  index.css         # Global styles & theme
index.html
vite.config.ts
```

## Contact

- Phone: 7209320992
- Email: ghanshyamroy724@gmail.com
