export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black/50 backdrop-blur-lg py-12 relative z-10">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <a href="#" className="text-3xl font-heading font-bold text-white tracking-wider hover:text-primary transition-colors inline-block mb-2">
            GR<span className="text-primary">.</span>
          </a>
          <p className="text-muted-foreground">Let's build something clean, fast, and memorable.</p>
        </div>
        
        <div className="flex gap-6 text-sm font-medium">
          <a href="#about" className="text-muted-foreground hover:text-white transition-colors">About</a>
          <a href="#projects" className="text-muted-foreground hover:text-white transition-colors">Projects</a>
          <a href="#services" className="text-muted-foreground hover:text-white transition-colors">Services</a>
          <a href="#contact" className="text-muted-foreground hover:text-white transition-colors">Contact</a>
        </div>

        <div className="text-sm text-muted-foreground/50 text-center md:text-right">
          &copy; {new Date().getFullYear()} Ghanshyam Roy. <br className="hidden md:block" /> All rights reserved.
        </div>
      </div>
    </footer>
  );
}
