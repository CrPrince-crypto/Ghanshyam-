import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const links = ["About", "Skills", "Projects", "Services", "Contact"];

  return (
    <motion.nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? "bg-background/80 backdrop-blur-md border-b border-white/5 py-4" : "bg-transparent py-6"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        <a href="#" className="text-3xl font-heading font-bold text-white tracking-wider hover:text-primary transition-colors data-testid='nav-logo'">
          GR<span className="text-primary">.</span>
        </a>
        
        <ul className="hidden md:flex gap-8">
          {links.map((link) => (
            <li key={link}>
              <a 
                href={`#${link.toLowerCase()}`}
                className="text-sm font-medium text-muted-foreground hover:text-white transition-colors relative group data-testid={`nav-link-${link.toLowerCase()}`}"
              >
                {link}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
              </a>
            </li>
          ))}
        </ul>

        <a 
          href="#contact" 
          className="hidden md:inline-flex px-6 py-2 rounded-full border border-primary/50 text-primary hover:bg-primary hover:text-black transition-all font-medium data-testid='nav-cta'"
        >
          Let's Talk
        </a>
      </div>
    </motion.nav>
  );
}
