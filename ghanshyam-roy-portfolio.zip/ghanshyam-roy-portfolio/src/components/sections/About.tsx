import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "framer-motion";

function Counter({ end, suffix = "", duration = 2 }: { end: number, suffix?: string, duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const increment = end / (duration * 60);
      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 1000 / 60);
      return () => clearInterval(timer);
    }
  }, [end, duration, isInView]);

  return <span ref={ref}>{count}{suffix}</span>;
}

export default function About() {
  return (
    <section id="about" className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="grid lg:grid-cols-2 gap-16 items-center"
        >
          <div>
            <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-3">About Me</h2>
            <h3 className="text-4xl md:text-5xl font-heading font-bold text-white mb-6">
              Engineering <br /> <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Digital Excellence</span>
            </h3>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              I am Ghanshyam Roy, a passionate web developer and UI designer dedicated to building fast, premium, and mobile-first websites. 
              My expertise lies in responsive design, UI/UX, and modern business websites that don't just look good, but perform exceptionally.
            </p>
            <p className="text-muted-foreground text-lg leading-relaxed mb-10">
              Whether it's crafting a brand identity or developing a fully functional application, I bring precision and creative problem-solving to every project.
            </p>

            <div className="grid grid-cols-3 gap-6">
              <div className="glass-panel p-6 rounded-2xl text-center">
                <div className="text-3xl font-bold text-white mb-2"><Counter end={2} suffix="+" /></div>
                <div className="text-sm text-muted-foreground">Years of Experience</div>
              </div>
              <div className="glass-panel p-6 rounded-2xl text-center">
                <div className="text-3xl font-bold text-white mb-2"><Counter end={20} suffix="+" /></div>
                <div className="text-sm text-muted-foreground">Projects Completed</div>
              </div>
              <div className="glass-panel p-6 rounded-2xl text-center">
                <div className="text-3xl font-bold text-white mb-2"><Counter end={92} suffix="%" /></div>
                <div className="text-sm text-muted-foreground">Client Satisfaction</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="aspect-square rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 blur-3xl absolute inset-0"></div>
            <div className="glass-panel rounded-3xl p-8 relative z-10 border border-white/10">
               <div className="w-full h-[400px] rounded-2xl overflow-hidden bg-card/50 relative group">
                 {/* Placeholder for portrait/abstract art representing the developer */}
                 <img 
                   src="https://images.unsplash.com/photo-1517134191118-9d595e4c8c2b?w=800&q=80" 
                   alt="Premium UI Design Workspace" 
                   className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
               </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
