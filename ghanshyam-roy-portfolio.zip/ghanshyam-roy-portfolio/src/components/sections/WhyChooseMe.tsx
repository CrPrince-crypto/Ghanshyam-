import { motion } from "framer-motion";

export default function WhyChooseMe() {
  const points = [
    { title: "Fast Loading Websites", desc: "Optimized performance to ensure lightning-fast load times and better SEO." },
    { title: "Mobile Responsive", desc: "Flawless experience across all devices, from desktop to smartphone." },
    { title: "Premium Modern Design", desc: "Cinematic, futuristic aesthetics that make your brand stand out." },
    { title: "Smooth User Experience", desc: "Intuitive navigation and engaging micro-interactions." },
    { title: "Clean Code", desc: "Scalable, maintainable, and standard-compliant architecture." },
    { title: "Professional UI", desc: "Expert use of typography, spacing, and color theory for premium feel." }
  ];

  return (
    <section id="why-me" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-3">The Advantage</h2>
          <h3 className="text-4xl md:text-5xl font-heading font-bold text-white">Why Choose Me</h3>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {points.map((point, index) => (
            <motion.div
              key={point.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative pl-8"
            >
              <div className="absolute left-0 top-1 w-2 h-2 rounded-full bg-primary shadow-[0_0_10px_rgba(0,212,255,0.8)]"></div>
              <div className="absolute left-[3px] top-4 w-px h-[calc(100%-1rem)] bg-gradient-to-b from-primary/50 to-transparent"></div>
              <h4 className="text-xl font-bold text-white mb-2">{point.title}</h4>
              <p className="text-muted-foreground">{point.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
