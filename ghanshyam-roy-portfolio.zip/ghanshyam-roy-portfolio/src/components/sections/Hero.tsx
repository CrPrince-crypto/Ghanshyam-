import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { FaGithub, FaLinkedin, FaInstagram } from "react-icons/fa";

export default function Hero() {
  const roles = ["Web Developer", "Premium UI Designer", "Creative Builder", "Modern Web Creator"];
  const [currentRole, setCurrentRole] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentRole((prev) => (prev + 1) % roles.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="hero" className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] mix-blend-screen floating-particle" />
        <div className="absolute bottom-1/4 right-1/4 w-[30rem] h-[30rem] bg-secondary/10 rounded-full blur-[150px] mix-blend-screen floating-particle" style={{ animationDelay: "-5s" }} />
      </div>

      <div className="container mx-auto px-6 relative z-10 flex flex-col items-center text-center mt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <span className="inline-block py-1 px-3 rounded-full border border-white/10 bg-white/5 text-primary text-sm font-medium mb-6 backdrop-blur-sm">
            Available for Freelance Work
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-heading font-bold text-white mb-4 tracking-tight">
            Ghanshyam Roy
          </h1>
          <div className="h-12 md:h-16 overflow-hidden mb-6">
            <motion.div
              key={currentRole}
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -40, opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="text-2xl md:text-4xl font-light text-primary"
            >
              {roles[currentRole]}
            </motion.div>
          </div>
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground leading-relaxed mb-10">
            I craft modern, fast, and premium websites that leave lasting impressions. Turning ideas into stunning digital experiences.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="#projects"
              className="px-8 py-4 rounded-full bg-white text-black font-semibold hover:bg-primary transition-colors data-testid='hero-projects-btn'"
            >
              View Projects
            </a>
            <a 
              href="#contact"
              className="px-8 py-4 rounded-full border border-white/20 text-white font-semibold hover:bg-white/10 transition-colors data-testid='hero-hire-btn'"
            >
              Hire Me
            </a>
          </div>

          <div className="flex gap-6 justify-center mt-16">
            {[
              { icon: FaGithub, link: "#", id: "github" },
              { icon: FaLinkedin, link: "#", id: "linkedin" },
              { icon: FaInstagram, link: "#", id: "instagram" }
            ].map((social, i) => (
              <motion.a
                key={i}
                href={social.link}
                className="w-12 h-12 rounded-full glass-panel flex items-center justify-center text-white hover:text-primary hover:border-primary/50 transition-all data-testid={`social-${social.id}`}"
                whileHover={{ y: -5 }}
              >
                <social.icon size={20} />
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
