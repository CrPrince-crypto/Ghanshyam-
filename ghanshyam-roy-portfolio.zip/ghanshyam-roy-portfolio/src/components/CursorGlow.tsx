import { useEffect, useState } from "react";
import { motion } from "framer-motion";

export default function CursorGlow() {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 w-8 h-8 rounded-full pointer-events-none z-[9999] mix-blend-screen"
      style={{
        background: "radial-gradient(circle, rgba(0, 212, 255, 0.8) 0%, rgba(0, 123, 255, 0) 70%)",
        boxShadow: "0 0 20px 10px rgba(0, 212, 255, 0.5)",
      }}
      animate={{
        x: position.x - 16,
        y: position.y - 16,
      }}
      transition={{ type: "tween", ease: "backOut", duration: 0.1 }}
    />
  );
}
