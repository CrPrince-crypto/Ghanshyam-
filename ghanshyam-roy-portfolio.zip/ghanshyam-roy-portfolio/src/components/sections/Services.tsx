import { motion } from "framer-motion";
import { FaLaptopCode, FaMobileAlt, FaBuilding, FaPaintBrush, FaSyncAlt, FaLayerGroup } from "react-icons/fa";

export default function Services() {
  const services = [
    { title: "Website Design", icon: FaLaptopCode, desc: "Custom designed websites built from scratch to match your brand." },
    { title: "Landing Page Design", icon: FaLayerGroup, desc: "High-converting landing pages optimized for marketing campaigns." },
    { title: "Business Websites", icon: FaBuilding, desc: "Professional corporate websites that establish trust and authority." },
    { title: "Portfolio Websites", icon: FaPaintBrush, desc: "Creative showcases for freelancers, artists, and agencies." },
    { title: "Website Redesign", icon: FaSyncAlt, desc: "Modernize and upgrade your existing website for better performance." },
    { title: "Modern UI Design", icon: FaMobileAlt, desc: "Intuitive, clean, and futuristic user interfaces for web apps." }
  ];

  return (
    <section id="services" className="py-24 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-3">Offerings</h2>
          <h3 className="text-4xl md:text-5xl font-heading font-bold text-white">Services</h3>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-panel p-8 rounded-3xl glowing-border group"
            >
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon size={24} />
              </div>
              <h4 className="text-xl font-bold text-white mb-3">{service.title}</h4>
              <p className="text-muted-foreground leading-relaxed">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
