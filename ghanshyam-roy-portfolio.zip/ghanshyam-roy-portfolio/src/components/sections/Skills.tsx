import { motion } from "framer-motion";

export default function Skills() {
  const skills = [
    "HTML", "CSS", "JavaScript", "Responsive Design", 
    "UI Design", "Website Optimization", "Logo Design", "Video Editing"
  ];

  return (
    <section id="skills" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-3">Expertise</h2>
          <h3 className="text-4xl md:text-5xl font-heading font-bold text-white">Technical Arsenal</h3>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-panel rounded-2xl p-6 flex flex-col items-center justify-center text-center group glowing-border cursor-default"
            >
              <span className="text-lg font-medium text-white group-hover:text-primary transition-colors">{skill}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
