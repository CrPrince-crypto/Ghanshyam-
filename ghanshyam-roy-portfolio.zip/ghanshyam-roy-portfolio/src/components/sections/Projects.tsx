import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect, useCallback } from "react";

const projects = [
  {
    title: "School Education Platform",
    description: "Modern student portal with clean UI, course management, and mobile-first responsive design.",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=900&q=85",
    tag: "Web Design",
    link: "#"
  },
  {
    title: "Gym & Fitness App",
    description: "High-energy fitness landing page with bold typography, membership flow, and smooth animations.",
    image: "https://images.unsplash.com/photo-1559028006-448665bd7c7f?w=900&q=85",
    tag: "UI Design",
    link: "#"
  },
  {
    title: "Business Landing Page",
    description: "Conversion-focused corporate site with premium layout, hero sections, and lead generation.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=900&q=85",
    tag: "Landing Page",
    link: "#"
  },
  {
    title: "Portfolio Showcase",
    description: "Dark-mode personal brand website with glassmorphism, scroll animations, and project gallery.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=900&q=85",
    tag: "Portfolio",
    link: "#"
  },
  {
    title: "E-Commerce Store",
    description: "Full-featured product storefront with cart, filters, and fast-loading optimized design.",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=900&q=85",
    tag: "E-Commerce",
    link: "#"
  },
  {
    title: "SaaS Analytics Dashboard",
    description: "Data-rich dashboard UI with charts, KPI cards, and responsive layout for business tools.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=900&q=85",
    tag: "Dashboard",
    link: "#"
  },
  {
    title: "Restaurant & Food Website",
    description: "Elegant food brand site with full-screen imagery, reservation system, and menu showcase.",
    image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=900&q=85",
    tag: "Web Design",
    link: "#"
  },
  {
    title: "Real Estate Platform",
    description: "Property listing website with search filters, map integration, and premium card layout.",
    image: "https://images.unsplash.com/photo-1558655146-d09347e92766?w=900&q=85",
    tag: "UI Design",
    link: "#"
  }
];

export default function Projects() {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(1);
  const perPage = 2;
  const totalPages = Math.ceil(projects.length / perPage);

  const go = useCallback((dir: number) => {
    setDirection(dir);
    setCurrent((prev) => (prev + dir + totalPages) % totalPages);
  }, [totalPages]);

  useEffect(() => {
    const t = setInterval(() => go(1), 5000);
    return () => clearInterval(t);
  }, [go]);

  const visible = projects.slice(current * perPage, current * perPage + perPage);

  const variants = {
    enter: (d: number) => ({ x: d > 0 ? 80 : -80, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (d: number) => ({ x: d > 0 ? -80 : 80, opacity: 0 }),
  };

  return (
    <section id="projects" className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-3">Work</h2>
          <h3 className="text-4xl md:text-5xl font-heading font-bold text-white">Selected Projects</h3>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            A curated set of premium web experiences — each built with attention to detail, performance, and visual excellence.
          </p>
        </motion.div>

        {/* Slider */}
        <div className="relative overflow-hidden">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={current}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="grid md:grid-cols-2 gap-8"
            >
              {visible.map((project, index) => (
                <div
                  key={project.title}
                  data-testid={`project-card-${current * perPage + index}`}
                  className="group relative rounded-3xl overflow-hidden glass-panel glowing-border p-1"
                >
                  <div className="bg-card rounded-[1.4rem] overflow-hidden relative">
                    <div className="aspect-[16/10] overflow-hidden relative">
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/30 to-transparent" />
                      <span className="absolute top-4 right-4 text-xs font-semibold text-primary bg-primary/10 border border-primary/20 px-3 py-1 rounded-full backdrop-blur-sm">
                        {project.tag}
                      </span>
                    </div>
                    <div className="p-8">
                      <h4 className="text-2xl font-bold text-white mb-3">{project.title}</h4>
                      <p className="text-muted-foreground text-sm leading-relaxed mb-6">{project.description}</p>
                      <a
                        href={project.link}
                        data-testid={`project-link-${current * perPage + index}`}
                        className="inline-flex items-center gap-2 text-primary font-medium hover:text-white transition-colors group/link"
                      >
                        Live Preview
                        <svg
                          className="w-4 h-4 group-hover/link:translate-x-1 transition-transform"
                          fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-6 mt-12">
          <button
            data-testid="projects-prev"
            onClick={() => go(-1)}
            className="w-12 h-12 rounded-full glass-panel border border-white/10 flex items-center justify-center text-white hover:text-primary hover:border-primary/40 transition-all"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="flex gap-2">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                data-testid={`projects-dot-${i}`}
                onClick={() => { setDirection(i > current ? 1 : -1); setCurrent(i); }}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === current ? "bg-primary w-8" : "bg-white/20 w-2"
                }`}
              />
            ))}
          </div>

          <button
            data-testid="projects-next"
            onClick={() => go(1)}
            className="w-12 h-12 rounded-full glass-panel border border-white/10 flex items-center justify-center text-white hover:text-primary hover:border-primary/40 transition-all"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        <p className="text-center text-muted-foreground text-sm mt-4">
          {current * perPage + 1}–{Math.min(current * perPage + perPage, projects.length)} of {projects.length} projects
        </p>
      </div>
    </section>
  );
}
