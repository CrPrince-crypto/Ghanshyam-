import { motion } from "framer-motion";
import { FaWhatsapp, FaEnvelope, FaInstagram, FaPhone } from "react-icons/fa";

export default function Contact() {
  return (
    <section id="contact" className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-5xl mx-auto glass-panel rounded-3xl p-8 md:p-12 overflow-hidden relative"
        >
          {/* Decorative glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[80px] pointer-events-none"></div>

          <div className="text-center mb-12 relative z-10">
            <span className="inline-flex items-center gap-2 py-1 px-3 rounded-full border border-primary/30 bg-primary/10 text-primary text-sm font-medium mb-6">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
              Available for Freelance Work
            </span>
            <h2 className="text-4xl md:text-6xl font-heading font-bold text-white mb-4">Let's Work Together</h2>
            <p className="text-muted-foreground text-lg">Ready to build something extraordinary? Drop me a message.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 relative z-10">
            <div>
              <div className="space-y-8 mb-10">
                <div className="flex items-center gap-4 group">
                  <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-primary group-hover:bg-primary/20 transition-colors">
                    <FaPhone size={20} />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Call Me</div>
                    <a href="tel:7209320992" className="text-lg font-medium text-white hover:text-primary transition-colors">7209320992</a>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 group">
                  <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-primary group-hover:bg-primary/20 transition-colors">
                    <FaEnvelope size={20} />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Email Me</div>
                    <a href="mailto:ghanshyamroy724@gmail.com" className="text-lg font-medium text-white hover:text-primary transition-colors">ghanshyamroy724@gmail.com</a>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <a href="#" className="flex-1 glass-panel py-3 flex items-center justify-center gap-2 rounded-xl text-white hover:text-green-400 hover:border-green-400/50 transition-all data-testid='contact-whatsapp'">
                  <FaWhatsapp size={20} /> WhatsApp
                </a>
                <a href="#" className="flex-1 glass-panel py-3 flex items-center justify-center gap-2 rounded-xl text-white hover:text-pink-400 hover:border-pink-400/50 transition-all data-testid='contact-instagram'">
                  <FaInstagram size={20} /> Instagram
                </a>
              </div>
            </div>

            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <input 
                  type="text" 
                  placeholder="Your Name" 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                  data-testid="contact-name"
                />
              </div>
              <div>
                <input 
                  type="email" 
                  placeholder="Your Email" 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                  data-testid="contact-email"
                />
              </div>
              <div>
                <textarea 
                  rows={4}
                  placeholder="Your Message" 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all resize-none"
                  data-testid="contact-message"
                ></textarea>
              </div>
              <button 
                type="submit"
                className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-primary transition-colors data-testid='contact-submit'"
              >
                Send Message
              </button>
            </form>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
