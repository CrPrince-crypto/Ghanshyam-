import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Arjun Sharma",
      role: "Business Owner",
      text: "Ghanshyam delivered exactly what we needed. The site is incredibly fast, looks premium, and has significantly improved our brand image."
    },
    {
      name: "Priya Mehta",
      role: "Startup Founder",
      text: "Working with him was a breeze. He understands modern design trends and executed a flawless, mobile-first experience for our users."
    },
    {
      name: "Rahul Verma",
      role: "Freelancer",
      text: "The portfolio website he built for me is stunning. The animations and dark mode design perfectly capture the cinematic vibe I wanted."
    }
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  return (
    <section id="testimonials" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-3">Client Feedback</h2>
          <h3 className="text-4xl md:text-5xl font-heading font-bold text-white">Testimonials</h3>
        </div>

        <div className="max-w-4xl mx-auto relative h-[300px]">
          {testimonials.map((test, index) => (
            <motion.div
              key={index}
              className="absolute inset-0 flex flex-col items-center justify-center text-center glass-panel p-10 rounded-3xl"
              initial={{ opacity: 0, x: 50 }}
              animate={{ 
                opacity: activeIndex === index ? 1 : 0, 
                x: activeIndex === index ? 0 : (activeIndex > index ? -50 : 50),
                pointerEvents: activeIndex === index ? "auto" : "none"
              }}
              transition={{ duration: 0.6, ease: "easeInOut" }}
            >
              <svg className="w-12 h-12 text-primary/40 mb-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
              </svg>
              <p className="text-xl md:text-2xl text-white font-medium italic mb-8 leading-relaxed">
                "{test.text}"
              </p>
              <div>
                <div className="font-bold text-primary">{test.name}</div>
                <div className="text-sm text-muted-foreground">{test.role}</div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="flex justify-center gap-3 mt-8">
          {testimonials.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveIndex(idx)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${activeIndex === idx ? 'bg-primary w-8' : 'bg-white/20'}`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
